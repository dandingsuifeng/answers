# -*- coding: utf-8 -*-
L = ['Hello', 'World', 18, 'Apple', None]
L2 = []
for x in L:
    if (isinstance(x, str)):
        L2.append(x.lower())
print(L2)
