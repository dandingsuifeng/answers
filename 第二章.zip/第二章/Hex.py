# -*- coding: utf-8 -*-
n1 = 255
n2 = 1000
print(hex(n1))
print(hex(n2))