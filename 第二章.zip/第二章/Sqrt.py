# -*- coding: utf-8 -*-
import math
def quadratic(a,b,c):
    if a==0:
        print('非二次方程')
    if b*b-4*a*c <0 :
        answera,answerb = '无根'
        return answera,answerb
    if b*b-4*a*c == 0 :
        return 0,0
    tin = math.sqrt(b*b - 4*a*c)
    answera = (-b + 2*tin )/(2*a)
    answerb = (-b - 2*tin)/(2*a)
    return answera,answerb

print(quadratic(2, 3, 1))