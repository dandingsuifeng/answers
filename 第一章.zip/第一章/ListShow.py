# -*- coding: utf-8 -*-
L = ['Bart', 'Lisa', 'Adam']
for a in L:
    print('Hello,%s' % a )