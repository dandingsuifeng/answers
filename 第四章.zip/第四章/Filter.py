# -*- coding: utf-8 -*-


def is_palindrome(n):
    n_str = str(n)
    if (n_str == n_str[::-1]):
        print(n_str)



output = filter(is_palindrome, range(1,10000))
print(list(output))
